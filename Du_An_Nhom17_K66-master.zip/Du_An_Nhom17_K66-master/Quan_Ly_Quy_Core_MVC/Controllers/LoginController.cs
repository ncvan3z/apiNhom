﻿using Microsoft.AspNetCore.Mvc;
using Quan_Ly_Quy_Core_MVC.Models;
using Quan_Ly_Quy_Core_MVC.Class;
namespace Quan_Ly_Quy_Core_MVC.Controllers
{
    public class LoginController : Controller
    {
        private readonly WebsiteContext _context;

        public LoginController(WebsiteContext context)
        {
            _context = context;
        }

        // GET: Login
        public IActionResult Index()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public IActionResult Index(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _context.Users.FirstOrDefault(u => u.Username == model.Username && u.Password == model.Password);
                if (user != null)
                {
                    // Login successful
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    // Login failed
                    ModelState.AddModelError("", "Invalid username or password");
                }
            }
            return View(model);
        }
    }

}
