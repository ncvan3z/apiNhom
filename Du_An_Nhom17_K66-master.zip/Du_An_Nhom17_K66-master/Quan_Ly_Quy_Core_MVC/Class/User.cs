﻿using System.ComponentModel.DataAnnotations;

namespace Quan_Ly_Quy_Core_MVC.Class
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Username is required!")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required!")]
        public string Password { get; set; }
    }

}
