﻿using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using Quan_Ly_Quy_Core_MVC.Models;
using Microsoft.EntityFrameworkCore;

namespace Quan_Ly_Quy_Core_MVC.Class
{
    public class WebsiteContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
        }
    }
}
