﻿namespace Quan_Ly_Quy_Core_MVC.Class;
using Microsoft.EntityFrameworkCore;
using Quan_Ly_Quy_Core_MVC.Models;

{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddControllersWithViews();
        services.AddDbContext<WebsiteContext>(options =>
          options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
    }
}