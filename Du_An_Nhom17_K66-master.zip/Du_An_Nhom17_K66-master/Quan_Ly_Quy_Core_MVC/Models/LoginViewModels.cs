﻿namespace Quan_Ly_Quy_Core_MVC.Models
{
    public class LoginViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }


}
