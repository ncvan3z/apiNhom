﻿using Microsoft.AspNetCore.Authentication;
using System.ComponentModel.DataAnnotations;

namespace Quan_Ly_Quy_Core_API.Models
{
    public class NguoiDungQuy : People 
    {
        string msv;
        string tenSanPhamMua;
        int soLuongMua;
        int giasanPham;

        public string Msv { get => msv; set => msv = value; }
        public string TenSanPhamMua { get => tenSanPhamMua; set => tenSanPhamMua = value; }
        public int SoLuongMua { get => soLuongMua; set => soLuongMua = value; }
        public int GiasanPham { get => giasanPham; set => giasanPham = value; }

        public NguoiDungQuy()
        {
        }

        public NguoiDungQuy(string _msv, string _hodem, string _ten, string _bietdanh, string _email, string _dienthoai, int _tuoi, string _tenSanPhamMua, int _soLuongMua, int _giasanPham) : base( _hodem, _ten, _bietdanh, _email, _dienthoai, _tuoi)
        {
            this.Msv = _msv;
            
            this.Hodem = _hodem;
            this.Ten = _ten;
            this.Bietdanh = _bietdanh;
            this.Email = _email;
            this.Dienthoai = _dienthoai;
            this.Tuoi = _tuoi;
            this.TenSanPhamMua = _tenSanPhamMua;
            this.SoLuongMua = _soLuongMua;
            this.GiasanPham = _giasanPham;
        }

        static List<NguoiDungQuy> ds_sinhvien = new List<NguoiDungQuy>
            {
                 new NguoiDungQuy{ 
                          Msv        ="0011223344556",
                          Hodem       = "Nguyễn Văn"  ,
                          Ten         = "ABCXYZ"      ,
                          Bietdanh    = "ABCXYZ"      ,
                          Email       = "abc@demo.com",
                          Dienthoai   = "0979xxxx222" ,
                          Tuoi        = 0,
                          TenSanPhamMua="",
                          SoLuongMua=0,
                          GiasanPham=0

                     }

            };

        public override string GetInfo()
        {
            return $"{Msv} - {Hodem} {Ten}";
        }
    }
}
